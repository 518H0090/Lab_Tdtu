package tdtu.lab07.exam03;

public interface IStudentOption {
    void onDeleteStudent(int position);
}
